function [rate1]=main_1(X,item)     
%item:运行item次
%k:噪声率
y_index=[];
y_index1=[];
F1=[];
F=[];
ave_num=[];
ave_num1=[];
R_Best=[];
T=[];
T1=[];
index=1;
[m,n]=size(X);
block=10;
 while index<=item
       fprintf('第 %d 次训练\n', index);
       [train,test]=divid(X,0.3);
       test_num=size(test,1);
       train_num=size(train,1);
       %train=Noise(train,k);
       [Y1,R_Y1,num1,t1,best_radius] = external_graball(train,block);
       %[Y1,R_Y1,num1,t1,best_radius] = initial_external_graball(train,block);
       ave_num1=[ave_num1,num1];
       label_prediction=[];
       label_prediction1=[];
       T1=[T1,t1];
       R_Best=[R_Best,best_radius];
       [m3,~]=size(Y1);
       label_true=test(:,end);
       num_extent=max(sum(Y1(:,1:train_num),2));
    for i=1:test_num
        distance1=sqrt(sum((Y1(:,(train_num+1):end-1)-repmat(test(i,1:end-1),m3,1)).^2,2));
        position1=find(distance1==min(distance1));
        label_prediction1(i,1)=Y1(position1(1),end);
    end
    y1=length(find((label_true-label_prediction1)==0))/test_num;
    f1=macro_f1(label_true, label_prediction1);
    y_index1=[y_index1;y1];
    F1=[F1;f1];
    index=index+1;
 end
F11=sort(F1,'descend');
f1_sore=mean(F11,1)*100;
standf=std(F11*100);
y2=sort(y_index1,'descend');
acc1=mean(y2)*100;
ave_num1=mean(ave_num1);
rate1=ave_num1/train_num;
stand1=std(y2)*100;
R_Best=mean(R_Best);
t=mean(T1);
af=[acc1,f1_sore];
stand=[stand1,standf];
fprintf('GBFCCL的acc和标准差是 %.2f±%.2f\n', af(1), stand(1));
fprintf('GBFCCL的f1和标准差是 %.2f±%.2f\n', af(2), stand(2));
fprintf('GBFCCL的MAX acc是 %.2f\n',max(y2)*100);
fprintf('GBFCCL的MAX f1是 %.2f\n', max(F11)*100);
end