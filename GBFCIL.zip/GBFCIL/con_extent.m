function y=con_extent(m0,n0,a1,idx,deoverlap_balls,x)
deoverlap_balls1=[];
[m,~]=size(x);
for z=1:a1%外延维度保持一致
    extent_z=zeros(1,m0);
    position_de=find(deoverlap_balls(z,1:m)==1);
    trans_deoverlap_balls=deoverlap_balls(z,:);
    extent_z(idx(position_de)')=1;
    deoverlap_balls1=[deoverlap_balls1;[extent_z,trans_deoverlap_balls(:,(end-n0+1):end)]];
end
y=deoverlap_balls1;