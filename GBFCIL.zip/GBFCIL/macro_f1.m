function  f1= macro_f1(y_true, y_pred)
    % 输入：
    % y_true: 实际标签向量
    % y_pred: 预测标签向量
    
    % 构建混淆矩阵
    [C, labels] = confusionmat(y_true, y_pred);
    n_classes = length(labels);
    f1_per_class = zeros(1, n_classes);

    for i = 1:n_classes
        TP = C(i, i);%正类
        FP = sum(C(:, i)) - TP;
        FN = sum(C(i, :)) - TP;
        precision = TP / (TP + FP + eps);
        recall = TP / (TP + FN + eps);
        f1_per_class(i) = 2 * (precision * recall) / (precision + recall + eps);
    end

    % 宏平均 F1
    f1 = mean(f1_per_class);
end