function [deoverlap_balls,deoverlap_r] = overlap_resolve(data,granular_balls,r)
% data：原始数据,
% granular_balls：现有粒球(前 m 列为样本指示，后面为中心和标签),
% r：现有粒球的半径(列向量)

[m,~]  = size(data);              % 样本数
data_no_label = data(:,1:end-1);  % 去掉标签
[m1,~] = size(granular_balls);    % 粒球个数

overlap_ball = [];
di = [];

% ===== 第一次找重叠的粒球 =====
for i = 1:m1
    for j = 1:m1
        if i < j
            num_i = sum(granular_balls(i,1:m));
            num_j = sum(granular_balls(j,1:m));

            if pdist2(granular_balls(i,m+1:end-1), ...
                      granular_balls(j,m+1:end-1)) < r(i)+r(j)

                if r(i) > r(j) && num_i > 1
                    overlap_ball = [overlap_ball; granular_balls(i,:)];
                    di = [di, i];
                elseif r(j) > r(i) && num_j > 1
                    overlap_ball = [overlap_ball; granular_balls(j,:)];
                    di = [di, j];
                end
            end
        end
    end
end

di          = unique(di);
overlap_ball = unique(overlap_ball,'rows');
[num,~]     = size(overlap_ball);

% ===== 如果一开始就没有重叠，直接返回原粒球 =====
if num == 0
    deoverlap_balls = granular_balls;
    deoverlap_r     = r;
    return;
end

% 删除要去重叠的“大球”，剩下的是一直保留的粒球
granular_balls(di,:) = [];
r(di,:)              = [];

% ===== 反复分裂重叠的大球，直到没有重叠 =====
while true
    balls   = [];   % 分裂出来的新粒球
    r_balls = [];   % 新粒球半径

    % --- 对当前待分裂的每个重叠球做 K-means 分裂 ---
    for p = 1:num
        gb_sample = find(overlap_ball(p,1:m) == 1);  % 第 p 个球的样本索引

        [idx, centroids] = kmeans(data_no_label(gb_sample,:), 2);

        % 第一簇
        a = zeros(1,m);
        a(gb_sample(idx==1)) = 1;
        a_point    = find(a==1);
        a_position = find(data(a_point,end) == mode(data(a_point,end)));
        a_label    = data(a_point(a_position(1)), end);
        r_a        = max(pdist2(data_no_label(a_point,:), centroids(1,:)));

        balls   = [balls; [a, centroids(1,:), a_label]];
        r_balls = [r_balls; r_a];

        % 第二簇
        b = zeros(1,m);
        b(gb_sample(idx==2)) = 1;
        b_point    = find(b==1);
        b_position = find(data(b_point,end) == mode(data(b_point,end)));
        b_label    = data(b_point(b_position(1)), end);
        r_b        = max(pdist2(data_no_label(b_point,:), centroids(2,:)));

        balls   = [balls; [b, centroids(2,:), b_label]];
        r_balls = [r_balls; r_b];
    end

    % 用分裂后的球替换当前重叠球集合
    overlap_ball = balls;
    [num,~]      = size(overlap_ball);

    % 再次检测这些新球之间是否还有重叠
    new_overlap_ball = [];
    di = [];

    for i = 1:num
        for j = 1:num
            if i < j
                num_i = sum(overlap_ball(i,1:m));
                num_j = sum(overlap_ball(j,1:m));

                if pdist2(overlap_ball(i,m+1:end-1), ...
                          overlap_ball(j,m+1:end-1)) < r_balls(i)+r_balls(j)

                    if r_balls(i) > r_balls(j) && num_i > 1
                        new_overlap_ball = [new_overlap_ball; overlap_ball(i,:)];
                        di = [di, i];
                    elseif r_balls(j) > r_balls(i) && num_j > 1
                        new_overlap_ball = [new_overlap_ball; overlap_ball(j,:)];
                        di = [di, j];
                    end
                end
            end
        end
    end

    di             = unique(di);
    new_overlap_ball = unique(new_overlap_ball,'rows');
    overlap_ball   = new_overlap_ball;
    [num,~]        = size(overlap_ball);

    if num == 0
        % 已经没有重叠，把所有分裂后的球并入，返回
        granular_balls = [granular_balls; balls];
        r              = [r; r_balls];
        deoverlap_balls = granular_balls;
        deoverlap_r     = r;
        return;
    else
        % 还有重叠：先去掉本轮仍然重叠的大球，保留其它，再继续 while
        balls(di,:)   = [];
        r_balls(di,:) = [];
        granular_balls = [granular_balls; balls];
        r              = [r; r_balls];
    end
end

end
  




