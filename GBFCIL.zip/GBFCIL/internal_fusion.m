function [Y0,R_Y0,rate,merge_rate,iso_rate]=internal_fusion(X,block,r,block_i)
%[Y0,R_Y0,m1]=internal_fusion(X,block,r,block_i)
[m,n]=size(X);
num_block=floor(m/block); 
%第i块的内部融合过程
Y0=[zeros(1,m),X((block_i-1)*num_block+1,:)];%每一块的粒球概念过渡集:第一个样本直接看成以r为半径的粒球
Y0((block_i-1)*num_block+1)=1;
num_Y0=size(Y0,1);
R_Y0=[r];
Purity=[1];
merge_num=0;
iso_num=0;
for j=(block_i-1)*num_block+2:block_i*num_block%第i块中样本
    index=0;
    for k=1:num_Y0
        if pdist([X(j,1:end-1);Y0(k,m+1:end-1)],'euclidean')<R_Y0(k)+r%如果新样本和已有球相交
           index=1;
           Y0(k,j)=1; %外延中添加新进入的对象
           position_extent=find(Y0(k,1:m)~=0);%更新后的外延中对象标号
           extent_num=length(position_extent);%更新后的外延个数
           intent_correct=((extent_num-1)*Y0(k,m+1:end-1)+X(j,1:end-1))/extent_num;
           %混合后的粒球的球心
           Y0(k,end)=mode(X(position_extent,end));
           %粒球的标签
           Y0(k,m+1:end-1)=intent_correct;
           R_Y0(k,1)=max(pdist2(X(position_extent,1:end-1),intent_correct,'euclidean'));
           %R_Y0(k,1)=mean(pdist2(X(position_extent,1:end-1),intent_correct,'euclidean'));
           Purity(k,1)=size(find(X(position_extent,end)==mode(X(position_extent,end))),1)/extent_num;
        end
    end
   if index==0%前面未发生任何融合
   iso_num=iso_num+1;
   extent_new=zeros(1,m);
   extent_new(j)=1;
   Y_new=[extent_new,X(j,:)];
   Y0=[Y0;Y_new];
   R_Y0=[R_Y0;r];%粒球半径更新
   Purity=[Purity;1];
   end
   num_Y0=size(Y0,1);
   merge_num=merge_num+index;
end
merge_rate=merge_num/num_block;
iso_rate=iso_num/num_block;
%
%纯度过滤过程
for l=1:num_Y0
    other_l=setdiff([1:1:num_Y0],l);
    if Purity(l)<0.9 && all(sum(Y0(other_l,1:m),1))==1
       Y0(l,:)=zeros(1,m+n);
    end
end
Y0(all(Y0 == 0, 2), :) = [];
R_Y0(all(Y0 == 0, 2))=[];
[m1,~]=size(Y0);
rate=m1/num_block;