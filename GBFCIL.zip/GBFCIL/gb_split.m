function [y,gb_r]=gb_split(data) 
%[y,r,Pur]=gb_split(data,granular_balls,purity,min_sample) 
%[y,r,Pur]=gb_split(data,purity,min_sample) 
min_sample=2;
purity=0.9;
[m,~]=size(data);%m:样本总数；n:特征数
data_no_label=data(:,1:end-1);
granular_balls=[ones(1,m),mean(data_no_label)];%整体数据看作一个初始化的粒球
r=[];%初始半径是空集；
i=1;
[ll,~]=size(granular_balls);%粒球的个数
while i>0 % while true
      gb=granular_balls(i,:);%遍历第i个球
      gb_sample=find(granular_balls(i,1:m)==1);%第i个球中的样本序号
      num_gb_sample=sum(granular_balls(i,1:m));%球中的样本个数
      if size(find(data(gb_sample,end)==mode(data(gb_sample,end))),1)/num_gb_sample<purity && num_gb_sample>min_sample
         %如果纯度小于阈值且球中点个数大于最小值，就要进行分裂
         [idx, centroids] = kmeans(data_no_label(gb_sample,:), 2);%分裂第i个球中的样本
         a=zeros(1,m);
         a(gb_sample(find(idx==1)))=1;%找第一簇样本的索引
         granular_balls(i,:)=[a,centroids(1,:)];
         b=zeros(1,m);
         b(gb_sample(find(idx==2)))=1;%找第二簇样本的索引
         granular_balls=[granular_balls;[b,centroids(2,:)]];
         ll=ll+1;%分裂后粒球个数增加
      else%若不再分裂，则分析下一个球 
         i=i+1;
      if i>=ll
         break
      end
      end
end
y=granular_balls;
%%绘制粒球
[num,~]=size(granular_balls);%分裂后粒球的个数
y_label=[];
Pur=[];
gb_r=[];
for j=1:num 
    gb_point=find(granular_balls(j,1:m)==1);%第i个球中的样本序号
    point_position=find(data(gb_point,end)==mode(data(gb_point,end)));
    y_label=[y_label;data(gb_point(point_position(1)),end)];%粒球的标签
    gb_r=[gb_r;max(pdist2(data_no_label(gb_point,:),granular_balls(j,m+1:end)))]; % 半径
    Pur=[Pur;size(find(data(gb_point,end)==mode(data(gb_point,end))),1)/sum(granular_balls(j,1:m))];
    %granular_balls(j,m+1:end):球心
    %data_no_label(gb_point,:)：球中的样本点
% 定义圆心和半径
%     centerX = granular_balls(j,m+1); % 球心x坐标
%     centerY = granular_balls(j,m+2); % 球心y坐标
%     radius = max(pdist2(data_no_label(gb_point,1:2),granular_balls(j,m+1:m+2))); % 前两维半径
%     % 计算角度范围
%     theta = linspace(0, 2*pi, 100); % 从0到2*pi生成100个点
% 
%     % 计算圆上的点
%     r = ones(size(theta)) * radius; % 所有点都在半径上
%     x = centerX + r .* cos(theta); % x坐标
%     y = centerY + r .* sin(theta); % y坐标
%     % 绘制圆
%     plot(x, y, 'b-'); % 使用'b-'表示蓝色实线
%     hold on; % 保持当前图形
%     axis equal; % 保持纵横比，确保画出的圆是圆形
end
y=[y,y_label];


