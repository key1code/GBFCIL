function [Y,R_Y,num,t,best_r] = initial_external_graball(X,block)%计算粒球概念
t=tic;
%分层抽样优化半径
%X：原始数据，最后一列是标签
%r:此次概念认知过程的粒球初始半径
%block:块的个数
data=X;
[m0,n0]=size(X);
initial_num = round(m0*(0.05)); % 抽取构成粒球初始空间的样本;
[~,idx]=sort(rand(m0,1));
X0=X(idx(1:initial_num),:);
[granular_balls,gb_r]=gb_split(X0);
[deoverlap_balls0,deoverlap_r]=overlap_resolve(X0,granular_balls,gb_r);
%% 初始空间外延维度一致化
[a1,~]=size(deoverlap_balls0);%初始粒球空间粒球个数；
deoverlap_balls=con_extent(m0,n0,a1,idx(1:initial_num),deoverlap_balls0,X0);
%%
X=X(idx(initial_num+1:m0),:);%保存剩余的数据为动态认知;
[m,~]=size(X);
p=length(unique(X(:,end)));
r=[];
%num_Y0:粒球概念的总个数
%%
%内部生成过程
for i=1:block
    [Y00,R_Y0,best_radius]=PSO_Sampling_Optima(X,i,block,[0.0001,0.1]);
    %%
    %过渡空间外延维度一致化
    r=[r,best_radius];
    num_Y0=size(Y00,1);
    Y0=con_extent(m0,n0,num_Y0,idx(initial_num+1:m0),Y00,X);
    %save Y0
    %%
    %外部融合
    if i==1
       Y=deoverlap_balls;
       R_Y=deoverlap_r;
    end
     for q=1:num_Y0%遍历每一阶段概念空间中的概念
         index1=0;
         num_Y=size(Y,1);
         for p=1:num_Y%遍历总概念空间中的概念 
            if pdist([Y(p,m0+1:end-1);Y0(q,m0+1:end-1)],'euclidean')<R_Y(p)+R_Y0(q)
               if Y(p,end)==Y0(q,end)
                   index1=1;
                   add_extent=find(Y0(q,1:m0)~=0);
                   Y(p,add_extent)=1;
                   Y_intent=mean([Y(p,m0+1:end-1);Y0(q,m0+1:end-1)]);
                   Y(p,m0+1:end-1)=Y_intent;
                   Y_extent=find(Y(p,1:m0)~=0);
                   %更新后的概念的外延编号
                   R_Y(p,1)=max(pdist2(data(Y_extent,1:end-1),Y_intent,'euclidean'));
               end
            end
         end
        if index1==0;
           Y=[Y;Y0(q,:)];
           R_Y=[R_Y;R_Y0(q)];
        end
     end
end
num=size(Y,1);
t=toc;
best_r=mean(r);
end



 
           
