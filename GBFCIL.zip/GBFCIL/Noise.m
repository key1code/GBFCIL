function [ noiseData ] = Noise(dataset,k)
% 假设你的原始数据存储在一个名为data的向量中
% 假设k为要添加噪声的百分比（0到100之间的值）
% 假设mu和sigma是高斯噪声的均值和标准差

% 对除了标签之外的数据进行加噪声
data = dataset(:,1:end-1);

% 1. 计算要添加噪声的数据点数量
numPoints = round(k * numel(data));
%numPoints

% 2. 随机选择要添加噪声的数据点的索引
selectedIndices = randperm(numel(data), numPoints);

% 3. 为选定的数据点添加高斯白噪声
mu = 0; % 高斯噪声的均值
sigma = 0.1; % 高斯噪声的标准差
noise = mu + sigma * randn(size(data(selectedIndices)));

% 4. 将噪声添加到选定的数据点
data(selectedIndices) = data(selectedIndices) + noise;

noiseData = data;
% 5. 限制数据在0到1之间
noiseData(noiseData < 0) = 0;
noiseData(noiseData > 1) = 1;

noiseData = [data dataset(:,end)];%%最后的输出加上标签

% splitNoiseData = split(noiseData);%%%%输出是按80%训练集 20%测试集
end

% 现在，data向量中的k%数据带有高斯白噪声
